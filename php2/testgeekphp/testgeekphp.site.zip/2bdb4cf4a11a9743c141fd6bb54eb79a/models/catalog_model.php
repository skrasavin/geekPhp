<?
include dirname(__DIR__).'../lib/config.php';
include dirname(__DIR__).'../lib/db.class.php';

$db = new PDO('mysql:host=localhost;dbname=barberdl_php2db;', 'barberdl_php2db', 'qweasd123');
    
    
function getGoods() {
    try {
        $db = new PDO('mysql:host=localhost;dbname=barberdl_php2db;', 'barberdl_php2db', 'qweasd123');
        $query = 'SELECT * FROM `catalog`';
        return $te = $db->query($query);
    }catch (PDOException $e) {
    echo $e;
    }
}
function getBasket() {
    try {
        $db = new PDO('mysql:host=localhost;dbname=barberdl_php2db;', 'barberdl_php2db', 'qweasd123');
        $query = 'SELECT * FROM `basket`';
        return $te = $db->query($query);

    } catch (PDOException $e) {
    }
}
function getOrders() {
    try {
        $db = new PDO('mysql:host=localhost;dbname=barberdl_php2db;', 'barberdl_php2db', 'qweasd123');
        $query = 'SELECT * FROM `orders`';
        return $te = $db->query($query);

    } catch (PDOException $e) {
    }
}


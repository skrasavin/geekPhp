<?
define('HOST', 'localhost');
define('DB', 'barberdl_php2db');
define('USER', 'barberdl_php2db');
define('PASS', 'qweasd123');
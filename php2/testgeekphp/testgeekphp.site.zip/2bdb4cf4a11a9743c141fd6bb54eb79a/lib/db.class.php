<?php
class db
{
    private static $_instance = null;

    private $db; // Ресурс работы с БД

    /*
     * Получаем объект для работы с БД
     */
    public static function getInstance()
    {
        if (self::$_instance == null) {
            self::$_instance = new db();
        }
        return self::$_instance;
    }

    /*
     * Запрещаем копировать объект
     */
    private function __construct() {}
    private function __clone() {}

    /*
     * Выполняем соединение с базой данных
     */
    public function Connect($host, $base, $user, $password)
    {
        // Формируем строку соединения с сервером
       return $this->db = new PDO('mysql:host=localhost;dbname=barberdl_php2db;', 'barberdl_php2db', 'qweasd123');

    }

    /*
     * Выполнить запрос к БД
     */
    public function Query($query, $params = array())
    {
        $res = $this->db->prepare($query);
        $res->execute($params);
        return $res;
    }

}

?>

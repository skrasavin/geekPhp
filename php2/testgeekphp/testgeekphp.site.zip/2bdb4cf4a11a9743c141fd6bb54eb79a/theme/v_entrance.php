<?php
?>

<form method="post" action="../models/admin_model.php?key=5">
    Name <input type="text" name="name">
    <br/><br/>
    Password  <input class='v_input' name="pass" type="text">
    <br/>
    <input class="v_button" type="submit" value="Войти">
</form>
